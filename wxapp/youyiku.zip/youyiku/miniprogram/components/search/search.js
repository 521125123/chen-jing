// components/search/search.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    imgLove:"https://6368-chenmujing-2gvu8h64e76e21a4-1304585122.tcb.qcloud.la/love.jpg?sign=71c78c69e9817236de9e61f91a4de5b6&t=1611109970"
  },

  /**
   * 组件的方法列表
   */
  methods: {

  }
})
